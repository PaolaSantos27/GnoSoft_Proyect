package com.gnosoft.proyectgnosoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectGnosoftApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectGnosoftApplication.class, args);
	}

}
